#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
	char nome[50], ender[50], curso[50];
} aluno;
